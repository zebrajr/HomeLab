static const char *extensions[] = {
    ".jpg", 
    ".jpeg", 
    ".png", 
    ".webp"
};
#define NUM_IMAGE_EXTENSIONS sizeof(extensions) / sizeof(extensions[0])